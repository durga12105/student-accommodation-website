<?php include 'db.php';
$id = $_GET['id'];
$p = $conn->query("SELECT * FROM properties WHERE id=$id")->fetch_assoc();
?>
<!DOCTYPE html>
<html><head>
<title><?php echo $p['name']; ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body>
<div class="container mt-4">
<a href="index.php">← Back to Listing</a>
<div class="row mt-3">
<div class="col-md-6">
<img src="https://via.placeholder.com/600x350" class="img-fluid rounded">
<div class="row mt-2">
<div class="col-4"><img src="https://via.placeholder.com/200x120" class="img-fluid rounded"></div>
<div class="col-4"><img src="https://via.placeholder.com/200x120" class="img-fluid rounded"></div>
<div class="col-4"><img src="https://via.placeholder.com/200x120" class="img-fluid rounded"></div>
</div>
</div>
<div class="col-md-6">
<h2><?php echo $p['name']; ?></h2>
<p>⭐ <?php echo $p['rating']; ?> | <?php echo $p['city']; ?> | <?php echo $p['gender']; ?></p>
<h4>Rs.<?php echo $p['price']; ?>/month</h4>
<p><?php echo $p['description']; ?></p>
<h5>Amenities:</h5>
<p>
<?php
$am = $conn->query("SELECT a.name FROM amenities a JOIN property_amenities pa ON a.id=pa.amenity_id WHERE pa.property_id=$id");
while($a = $am->fetch_assoc()){ echo '<span class="badge bg-primary me-1">'.$a['name'].'</span>'; }
?>
</p>
<a href="interested.php?property_id=<?php echo $p['id']; ?>" class="btn btn-danger w-100">❤️ Mark as Interested</a>
</div></div></div></body></html>