<?php include 'db.php';
if(isset($_POST['register'])){
$conn->query("INSERT INTO users (name,email,password,phone) VALUES ('".$_POST['name']."','".$_POST['email']."','".md5($_POST['password'])."','".$_POST['phone']."')");
echo "<script>alert('Registered! Now Login'); location.href='login.php';</script>";
}
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<div class="container mt-5" style="max-width:400px">
<h3>Register</h3>
<form method="POST">
<input name="name" class="form-control mb-2" placeholder="Name" required>
<input name="email" class="form-control mb-2" placeholder="Email" required>
<input name="password" type="password" class="form-control mb-2" placeholder="Password" required>
<input name="phone" class="form-control mb-2" placeholder="Phone" required>
<button name="register" class="btn btn-primary w-100">Register</button>
</form><a href="login.php">Already have account? Login</a></div>