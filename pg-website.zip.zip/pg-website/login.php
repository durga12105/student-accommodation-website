<?php session_start(); include 'db.php';
if(isset($_POST['login'])){
$r = $conn->query("SELECT * FROM users WHERE email='".$_POST['email']."' AND password='".md5($_POST['password'])."'")->fetch_assoc();
if($r){ $_SESSION['user_id']=$r['id']; $_SESSION['name']=$r['name']; header("Location: dashboard.php"); }
else echo "<script>alert('Wrong Login');</script>";
}
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<div class="container mt-5" style="max-width:400px">
<h3>Login</h3>
<form method="POST">
<input name="email" class="form-control mb-2" placeholder="Email" required>
<input name="password" type="password" class="form-control mb-2" placeholder="Password" required>
<button name="login" class="btn btn-success w-100">Login</button>
</form><a href="register.php">No account? Register</a></div>