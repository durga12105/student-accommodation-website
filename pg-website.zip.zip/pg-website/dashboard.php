<?php session_start(); include 'db.php';
if(!isset($_SESSION['user_id'])){ header("Location: login.php"); exit; }
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<div class="container mt-4">
<h3>Welcome, <?php echo $_SESSION['name']; ?> 👋</h3>
<a href="index.php" class="btn btn-primary">Browse PGs</a>
<a href="logout.php" class="btn btn-danger">Logout</a>
<h4 class="mt-4">Your Interested Properties:</h4>
<div class="row">
<?php
$uid = $_SESSION['user_id'];
$res = $conn->query("SELECT p.* FROM properties p JOIN interested_users i ON p.id=i.property_id WHERE i.user_id=$uid");
while($r = $res->fetch_assoc()){
?>
<div class="col-md-4"><div class="card p-3"><h5><?php echo $r['name']; ?></h5><p><?php echo $r['city']; ?> | Rs.<?php echo $r['price']; ?></p><a href="details.php?id=<?php echo $r['id']; ?>" class="btn btn-success">View</a></div></div>
<?php } ?>
</div></div>