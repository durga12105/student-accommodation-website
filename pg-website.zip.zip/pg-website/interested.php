<?php
session_start();
include 'db.php';
if(!isset($_SESSION['user_id'])){ header("Location: login.php"); exit; }
$pid = $_GET['property_id'];
$uid = $_SESSION['user_id'];
$conn->query("INSERT IGNORE INTO interested_users (user_id, property_id) VALUES ($uid, $pid)");
header("Location: dashboard.php");
?>