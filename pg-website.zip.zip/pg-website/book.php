<?php include 'db.php'; ?>
<!DOCTYPE html>
<html>
<head><title>Book Room - StayNest</title><link rel="stylesheet" href="style.css"></head>
<body>
<header><h1>🏠 Stay<span>Nest</span></h1><a href="index.php">Home</a></header>
<div style="max-width:500px; margin:30px auto; background:white; padding:25px; border-radius:12px;">
<?php
$rid = $_GET['room_id'];
$room = $conn->query("SELECT * FROM rooms WHERE id='$rid'")->fetch_assoc();
?>
<h2>Book <?php echo $room['room_no']; ?></h2>
<p><b><?php echo $room['type']; ?></b> - Rs.<?php echo $room['price']; ?>/month</p>
<hr>
<form method="POST">
<label>Your Email</label><br>
<input type="email" name="email" required style="width:100%; padding:10px; margin:10px 0;"><br>
<label>Check In Date</label><br>
<input type="date" name="check_in" required style="width:100%; padding:10px; margin:10px 0;"><br>
<label>Check Out Date</label><br>
<input type="date" name="check_out" required style="width:100%; padding:10px; margin:10px 0;"><br>
<input type="hidden" name="room_id" value="<?php echo $rid; ?>">
<button type="submit" name="book" style="width:100%; padding:12px; background:#2563eb; color:white; border:none; border-radius:8px; cursor:pointer;">Confirm Booking</button>
</form>
<?php
if(isset($_POST['book'])){
$email=$_POST['email']; $rid=$_POST['room_id']; $ci=$_POST['check_in']; $co=$_POST['check_out'];
if($conn->query("INSERT INTO bookings (email, room_id, check_in, check_out) VALUES ('$email','$rid','$ci','$co')")){
echo "<h3 style='color:green; text-align:center;'>✅ Booking Successful!</h3>";
} else { echo "<p style='color:red;'>Error: ".$conn->error."</p>"; }
}
?>
</div>
</body>
</html>