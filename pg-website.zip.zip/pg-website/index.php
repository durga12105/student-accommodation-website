<?php include 'db.php'; ?>
<!DOCTYPE html>
<html><head>
<title>Student PG - Listing</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body>
<nav class="navbar navbar-dark bg-dark px-3">
<a class="navbar-brand" href="index.php">Student PG</a>
<div>
<a href="index.php" class="text-white me-3 text-decoration-none">Home</a>
<a href="dashboard.php" class="text-white me-3 text-decoration-none">My Dashboard</a>
<a href="login.php" class="text-white me-3 text-decoration-none">Login</a>
<a href="register.php" class="btn btn-warning btn-sm">Register</a>
</div>
</nav>
<div class="container mt-4">
<h2 class="text-center">Find Your PG</h2>
<form method="GET" class="row g-2 my-4">
<div class="col-md-3"><input name="city" class="form-control" placeholder="City" value="<?php echo $_GET['city'] ?? ''; ?>"></div>
<div class="col-md-3"><input name="budget" type="number" class="form-control" placeholder="Max Budget" value="<?php echo $_GET['budget'] ?? ''; ?>"></div>
<div class="col-md-3"><select name="gender" class="form-control"><option value="">All Gender</option><option>Boys</option><option>Girls</option><option>Unisex</option></select></div>
<div class="col-md-3"><button class="btn btn-primary w-100">Filter</button></div>
</form>
<div class="row">
<?php
$sql = "SELECT * FROM properties WHERE 1=1";
if(!empty($_GET['city'])) $sql .= " AND city LIKE '%".$_GET['city']."%'";
if(!empty($_GET['budget'])) $sql .= " AND price <= ".$_GET['budget'];
if(!empty($_GET['gender'])) $sql .= " AND gender='".$_GET['gender']."'";
$res = $conn->query($sql);
while($r = $res->fetch_assoc()){
?>
<div class="col-md-4 mb-4">
<div class="card">
<img src="https://via.placeholder.com/400x200" class="card-img-top" style="height:200px;object-fit:cover">
<div class="card-body">
<h5><?php echo $r['name']; ?></h5>
<p><?php echo $r['city']; ?> | Rs.<?php echo $r['price']; ?>/month | <?php echo $r['gender']; ?> | ⭐ <?php echo $r['rating']; ?></p>
<a href="details.php?id=<?php echo $r['id']; ?>" class="btn btn-success w-100">View Details</a>
</div></div></div>
<?php } ?>
</div></div></body></html>